# Linea Iconset
Linea Iconset a free outline iconset  featuring 730+ Icons.

## Acknowledgments

There are acknowledgements spread throughout the source code if you look around, and you can also view a list of credits.

## Contributing

If you wish to contribute to the project. If you’re able to patch the bug or add the feature yourself – fantastic, make a pull request with the code. If you find a bug in a project you please create an [issue](https://github.com/linea-io/Linea-Iconset/issues/new).

## Versioning

Linea is currently maintained under the [Semantic Versioning guidelines](http://semver.org/).

## Contributors


**Dario Ferrando**
- [Website](http://www.dario.io/)
- [GitHub](https://github.com/DarioFerrando)

**Benjamin Sigidi**
- [Website](https://moozen.com/)
- [GitHub](https://github.com/benjaminsigidi)
